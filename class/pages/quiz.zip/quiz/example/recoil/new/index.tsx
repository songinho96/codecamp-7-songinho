import React from "react";
import QuizRecoil from "../../../../../src/components/units/example/write";

export default function QuizNewPage() {
  return <QuizRecoil />;
}
