
import ProductWrite from '../../../../../src/components/units/board/08-quiz-product/ProductWrite.container'

export default function ProductEditPage() {
  return (
    <ProductWrite isEdit={true} />
  )
}
