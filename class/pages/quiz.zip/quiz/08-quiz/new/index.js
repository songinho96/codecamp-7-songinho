import React from 'react'
import ProductWrite from '../../../../src/components/units/board/08-quiz-product/ProductWrite.container'

export default function ProductNewPage() {
  
  return (
    <ProductWrite isEdit={false}/>
  )
}
