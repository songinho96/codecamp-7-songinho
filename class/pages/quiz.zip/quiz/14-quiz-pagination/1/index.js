import PaginationContainer from "../container";

export default function Pagination() {
  return <PaginationContainer />;
}
