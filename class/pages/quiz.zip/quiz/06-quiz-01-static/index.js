import BoardWrite from "./06-quiz-01-src/BoardWrite.container"

export default function ContainerPresenterPage() {

  return (
    <BoardWrite />
  )

}
