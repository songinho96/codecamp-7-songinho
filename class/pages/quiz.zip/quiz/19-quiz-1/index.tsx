import React from "react";
import ImageUploadPage from "./imageUpload.container";

export default function ImageUploadMain() {
  return <ImageUploadPage />;
}
