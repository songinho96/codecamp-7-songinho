import StaticRoutedPage from "../../06-quiz-02-src/BoardDetail.container"

export default function ContainerPresenterPage() {


  return(
    <StaticRoutedPage />
  )
}