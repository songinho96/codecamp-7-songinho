import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 100px;
  background-color: #08eb94;
`;

export default function LayoutNavigationQuiz() {
  return <Wrapper>네비게이션 영역 Navigation</Wrapper>;
}
