import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 50px;
  background-color: gray;
`;

export default function LayoutFooterQuiz() {
  return <Wrapper>푸터영역 Footer</Wrapper>;
}
