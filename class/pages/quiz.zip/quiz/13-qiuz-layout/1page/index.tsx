import styled from "@emotion/styled";

const Wrapper = styled.div``;

export default function OnePage() {
  return <Wrapper>one 영역 입니다</Wrapper>;
}
