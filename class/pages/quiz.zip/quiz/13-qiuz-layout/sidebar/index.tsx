import styled from "@emotion/styled/";

const Wrapper = styled.div`
  width: 300px;
  height: 800px;
  background-color: blue;
`;

export default function LayoutSideBarQuiz() {
  return <Wrapper>사이드바 영역 Sidebar</Wrapper>;
}
