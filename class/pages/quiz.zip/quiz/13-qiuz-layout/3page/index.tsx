import styled from "@emotion/styled";

const Wrapper = styled.div``;

export default function ThreePage() {
  return <Wrapper>three 영역 입니다</Wrapper>;
}
