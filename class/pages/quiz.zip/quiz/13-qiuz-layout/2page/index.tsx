import styled from "@emotion/styled";

const Wrapper = styled.div``;

export default function TwoPage() {
  return <Wrapper>two 영역 입니다</Wrapper>;
}
