import Presenter from "../21-quiz-02-child";

export default function Container() {
  return (
    <div>
      {/* 1번  */}
      {/* {Presenter({ child: "철수" })} */}

      {/* 2번 */}
      {/* {Presenter({ child: "철수", age: 13 })} */}
    </div>
  );
}
