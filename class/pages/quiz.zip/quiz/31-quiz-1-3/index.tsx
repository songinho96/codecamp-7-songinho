export default function index() {
  return (
    <div>
      <img src="/images/하치1.webp" />
    </div>
  );
}
