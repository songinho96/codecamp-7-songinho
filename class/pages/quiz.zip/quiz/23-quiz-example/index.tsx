import React from "react";
import LoginPage from "../example/hoc/login";

export default function index() {
  return <LoginPage />;
}
